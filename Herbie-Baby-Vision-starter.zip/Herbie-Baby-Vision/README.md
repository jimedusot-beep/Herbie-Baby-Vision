# H.E.R.B.I.E. Baby Vision

A supervised, local-first AI engineering assistant for developing the H.E.R.B.I.E. expressive robot.

## Status

**V0.1 starter scaffold only.** No model, coding agent, robotics controller, or automation has been installed or connected. No physical hardware has been tested.

## Mission

Baby Vision may research, plan, propose code changes, and produce test evidence. H.E.R.B.I.E. remains a separate robot runtime. Baby Vision must not issue physical motion commands or autonomously deploy or merge changes.

## Proposed integrations

- OpenHands / OpenHands Agent SDK: candidate coding agent
- Ollama: candidate local model server (subject to computer capacity)
- Git/GitHub or Gitea: branches and human-reviewed changes
- pytest: tests
- Optional: LangGraph for persistent workflows, Open WebUI for a chat interface

See `docs/INTEGRATION_PLAN.md` and `docs/SAFETY.md`.

## Initial milestones

1. Confirm HP ZBook CPU, RAM, GPU, OS and available disk space.
2. Review licenses, security and version compatibility for each selected upstream.
3. Run a coding agent against a disposable sample repository only.
4. Capture logs, diffs and test results; require human approval for merges.
5. Integrate read-only H.E.R.B.I.E. project context.

## Existing H.E.R.B.I.E. repositories

- [Robot software](https://github.com/jimedusot-beep/Herbie)
- [Hardware engineering](https://github.com/jimedusot-beep/Herbie-cyborg-hardware)
- [Body / CAD](https://github.com/jimedusot-beep/3D-vision)

This repository is intended to be **private** initially.
