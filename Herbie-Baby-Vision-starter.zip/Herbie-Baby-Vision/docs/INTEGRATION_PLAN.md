# Open-source integration plan

Do not blindly copy upstream code. Prefer a documented API, a version-pinned dependency, or a small adapter. Verify license terms and preserve notices before distributing or importing source.

| Candidate | Proposed role | Initial decision |
|---|---|---|
| OpenHands | Isolated coding worker | Evaluate first |
| OpenHands Agent SDK | Agent execution interfaces | Evaluate with OpenHands |
| OpenHands Automation | Task execution patterns | Research only |
| OpenCode | Alternative coding worker | Compare, not run both by default |
| CrewAI | Multi-agent roles | Research only |
| LangGraph | Task state and approvals | Optional later |
| Microsoft Agent Framework | Handoffs and orchestration | Research only |
| AutoGen | Historical examples | Research only |
| Open WebUI | Local chat dashboard | Optional separate service |
| Ollama | Local model endpoint | Evaluate after machine inventory |
| Gitea | Private Git hosting | Optional later |

## Proposed workflow

Human task -> scope/permissions validation -> disposable branch and isolated workspace -> agent proposal -> automated tests -> audit log and diff -> human approval -> existing repository review and CI.

Never give an LLM direct access to robot motors, production secrets, deployment credentials, or unrestricted shell commands. No automatic merges.
